import { useLoader } from "@react-three/fiber";
import { Texture, TextureLoader } from "three";
import { SubElementOptions } from "types";
export interface loadtexture{
    name: string,
    texture: Texture

}
export default function textures_init_data(
subelements?: SubElementOptions[]
){

let init_data: loadtexture[] = []
if (subelements){
    subelements.map((sub: SubElementOptions)=>{
    if (sub.use_textures && sub.textures && sub.name) {
       let texture = useLoader(TextureLoader, sub.textures)
       texture.flipY = false
       texture.repeat.set(2,2)
       init_data.push({name: sub.name, texture: texture})
    }
    })

}
return init_data

}
