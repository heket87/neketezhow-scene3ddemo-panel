# Scene3D Panel — demo source

This is a simplified demo version of the Scene3D Grafana panel.

Included in this demo:

- basic 3D elements: cube, plane, sphere, text, custom shape, Line3D and groups;
- GLTF/GLB model loading only;
- basic color, texture, position, rotation, size, visibility and link settings;
- one default PerspectiveCamera only;
- default ambient scene light only.

Removed from this demo:

- element and subelement animation modules;
- custom light editor and custom light loaders;
- shadow support;
- computer-vision recognition tools;
- STL, OBJ and FBX model loading;
- extra camera types and split viewport rendering.
