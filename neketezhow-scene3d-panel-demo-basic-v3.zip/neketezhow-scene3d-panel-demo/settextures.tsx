import { DefaultLoadingManager, TextureLoader } from "three";

export const getTextures = (texture: string)=> new Promise((resolve, reject)=>{
    const loader = new TextureLoader();
    DefaultLoadingManager.onLoad = ()=>resolve(textures);
    const textures = [
      texture
    ].map(filename=>loader.load(filename));
  });
  
