import { ElementOptions } from "types";

export default function set_elements_texture(el: ElementOptions[]){
    let urls: string[] = []
    el.map((element)=>{
        urls.push(String(element.textures))
    })
    return urls
}
