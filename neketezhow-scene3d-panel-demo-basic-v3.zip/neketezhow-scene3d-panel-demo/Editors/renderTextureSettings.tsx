import { Field, Switch, Input,  Button, ComboboxOption } from "@grafana/ui";

import React from "react";
import { ElementOptions } from "types";
import { CollapsElement } from "./Collapsesible";

import { updateField } from "./BaseEditorFields";

 export default function RenderTextureSettings({thiselement,datasources,value, onChange}: {thiselement: ElementOptions,datasources: ComboboxOption[], value: ElementOptions[],  onChange: (val: ElementOptions[]) => void }){
     const [elementstexture,setelementstexture] = React.useState(thiselement.textures)
    
    return (
      <CollapsElement label="Texture settings" key="texture-settings">
            <Field label={"Rotate textures on Y"}>
              <Switch value={thiselement.texture_flipY} onChange={(e) => 
                updateField(value, thiselement, onChange, "texture_flipY", e.currentTarget.checked)
               }/>
            </Field>
 <Field label="Enter path to textures" description="Enter path to textures">
            <>
            <Input
                id={'texture'}
                value={elementstexture}
                placeholder="https://"
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                 
                  setelementstexture(e.currentTarget.value)

                 
                  
                         
                }}
              />
                <Button icon='save' onClick={()=>{
                updateField(value, thiselement, onChange, "textures", elementstexture)
              }
                }>Apply</Button>

              </>
            </Field>
                <Field label="Enable texture repeat">
                         <Switch 
                           defaultChecked={thiselement.texture_repeat ?? false}
                           onChange={e => updateField(value, thiselement, onChange, "texture_repeat", e.currentTarget.checked)}
                           label='Enable texture repeat'
                         />
                       </Field>
                       
                       {thiselement.texture_repeat && (
                         <CollapsElement label={"Texture repeat settings"}>
                           <Field label="Repeat on X" description="Texture repeat on X">
                             <Input
                               value={thiselement.texture_repeatx || ''}
                               placeholder="1"
                               onChange={e => updateField(value, thiselement, onChange, "texture_repeatx", e.currentTarget.value)}
                             />
                           </Field> 
                           
                           <Field label="Repeat on Y" description="Texture repeat on Y">
                             <Input
                               value={thiselement.texture_repeaty || ''}
                               placeholder="1"
                               onChange={e => updateField(value, thiselement, onChange, "texture_repeaty", e.currentTarget.value)}
                             />
                           </Field>
                           
                           <Field label="offset on X" description="texture offset on X">
                             <Input
                               value={thiselement.texture_offsetx || ''}
                               placeholder="0"
                               onChange={e => updateField(value, thiselement, onChange, "texture_offsetx", e.currentTarget.value)}
                             />
                           </Field>
                           
                           <Field label="offset on Y" description="texture offset on Y">
                             <Input
                               value={thiselement.texture_offsety || ''}
                               placeholder="0"
                               onChange={e => updateField(value, thiselement, onChange, "texture_offsety", e.currentTarget.value)}
                             />
                           </Field>
                         </CollapsElement>
                       )}
                    
      </CollapsElement>
    );
  };
