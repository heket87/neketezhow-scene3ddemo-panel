import React from 'react';
import { Button, ComboboxOption, Field } from '@grafana/ui';

import { CollapsElement } from 'Editors/Collapsesible';
import EditorButtonsHead, {
  handleAddElement,
  handleDeleteElement,
} from './Editor_buttons_head';
import { ElementOptions } from 'types';
import BaseEditorFields from './BaseEditorFields';
import ElementExtraEditors from './ElementExtraEditors';

type GroupsEditorProps = {
  value: ElementOptions[];
  thiselement: ElementOptions;
  onChange: (val: ElementOptions[]) => void;
  optionstypes: Array<ComboboxOption<string>>;
  datasources: Array<ComboboxOption<string>>;
  parentElement?: ElementOptions;
};

export default function GroupsEditor({
  value,
  thiselement,
  onChange,
  optionstypes,
  datasources,
}: GroupsEditorProps) {
  return (
    <>
      {thiselement.group_subs?.map((children: ElementOptions) => (
        <CollapsElement
          key={children.id}
          label={
            <EditorButtonsHead
              globaloptions={value}
              element={children}
              onChange={onChange}
              parentElement={thiselement}
            />
          }
        >
          <BaseEditorFields
            optionstypes={optionstypes}
            datasources={datasources}
            value={value}
            thiselement={children}
            onChange={onChange}
          />

          {children.type === 'group' && children.group_subs && (
            <Field label="Group elements">
              <GroupsEditor
                value={value}
                thiselement={children}
                onChange={onChange}
                optionstypes={optionstypes}
                datasources={datasources}
                parentElement={thiselement}
              />
            </Field>
          )}

          <ElementExtraEditors
            value={value}
            thiselement={children}
            datasources={datasources}
            onChange={onChange}
          />

          <Field>
            <Button
              icon="trash-alt"
              variant="destructive"
              onClick={() =>
                handleDeleteElement(value, children, thiselement, onChange)
              }
            >
              Delete element
            </Button>
          </Field>
        </CollapsElement>
      ))}

      <Field>
        <Button
          variant="secondary"
          icon="plus"
          size="sm"
          onClick={() => handleAddElement(thiselement, onChange, value)}
        >
          Add element
        </Button>
      </Field>
    </>
  );
}
