import { ComboboxOption, Field, Input, Switch } from "@grafana/ui";
import React from "react";
import { ElementOptions } from "types";
import { CollapsElement } from "./Collapsesible";

import { updateField } from "./BaseEditorFields";

export default function RenderLinkSettings({
  thiselement,
  datasources,
  value,
  onChange
}: {
  thiselement: ElementOptions;
  datasources: ComboboxOption[];
  value: ElementOptions[];
  onChange: (val: ElementOptions[]) => void;
}) {
  return (
    <CollapsElement label="Link settings">
      <Field label="Enter link">
        <Input
          value={thiselement.link || ""}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
            updateField(value, thiselement, onChange, "link", e.currentTarget.value)
          }
        />
      </Field>
      
      <Field label="Open in current window" description="">
        <Switch
         defaultChecked={thiselement.open_in_current ?? false}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            updateField(value, thiselement, onChange, "open_in_current", e.currentTarget.checked);
          }}
        />
      </Field>
    </CollapsElement>    
  );
}
