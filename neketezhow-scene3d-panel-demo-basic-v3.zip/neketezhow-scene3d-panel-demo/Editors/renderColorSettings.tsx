import { Field, Switch, Input,  ColorPicker, Combobox, ComboboxOption, Button } from "@grafana/ui";
import React, { ChangeEvent } from "react";
import { CenterPosition, ElementOptions } from "types";
import { CollapsElement } from "./Collapsesible";

import { HslColor, HslColorPicker } from 'react-colorful';
import { updateField } from "./BaseEditorFields";

export default function RenderColorSettings({
  thiselement,
  datasources,
  value,
  onChange
}: {
  thiselement: ElementOptions;
  datasources: ComboboxOption[];
  value: ElementOptions[];
  onChange: (val: ElementOptions[]) => void;
}) {
const [errorcoordinates, setErrorcoordinates] = React.useState<string | null>(null);
const [tempPoints, setTempPoints] = React.useState<any[]>([]);
const fileInputRefCoordinates = React.useRef<HTMLInputElement>(null);         

const handleButtonCoordinatesClick = () => {
  fileInputRefCoordinates.current?.click();
};
const gradientoptions: ComboboxOption[] = [{label: 'IDW',value:'IDW'},{label:"kriging",value:'kriging'},
  {label: "splain",value:"splain"},{label: 'RBF',value: 'RBF'}
]
const rbfoptions: ComboboxOption[] = [{label: 'linear',value:'linear'},{label:"gaussian",value:'gaussian'},
  {label: "multiquadric",value:"multiquadric"},{label: 'thinplate',value: 'thinplate'}
]
const handleFileUpload = React.useCallback((event: ChangeEvent<HTMLInputElement>) => {
  const file = event.target.files?.[0];
  if (!file) {return;}

  setErrorcoordinates(null);
  const reader = new FileReader();

  reader.onload = (e) => {
    try {
      const content = e.target?.result as string;
      const parsedData = JSON.parse(content);
      
      // Data structure validation
      if (!Array.isArray(parsedData)) {
        throw new Error('File must contain array of objects');
      }

      const processedData = parsedData.map((item, index) => {
        if (!item || typeof item !== 'object') {
          throw new Error(`Element ${index} is not an object`);
        }

        // Checking required fields
        if (!('x' in item)) {throw new Error(`Missing field 'x' in element ${index}`);}
        if (!('y' in item)) {throw new Error(`Missing field 'y' in element ${index}`);}
        if (!('data' in item)) {throw new Error(`Missing field 'data' in element ${index}`);}

        return {
          x: String(item.x),
          y: String(item.y),
          data: String(item.data)
        };
      });

      // Save to temporary state instead of immediate update
      setTempPoints(processedData);
    } catch (err: any) {
      setErrorcoordinates(`File processing error: ${err.message || 'Invalid data format'}`);
    }
  };

  reader.onerror = () => {
    setErrorcoordinates('File reading error');
  };

  reader.readAsText(file);
}, []);

// Function to apply loaded data
const applyUploadedPoints = () => {
  if (tempPoints.length > 0) {
    updateField(value, thiselement, onChange, "gradientcolor.points", tempPoints);
    // Clear temporary state
    setTempPoints([]);
  }
};
  return (
    <CollapsElement label="Color settings" key="color-settings">
      <Field label="Use query for element color" description="Use query for color">
        <Switch 
          
          defaultChecked={thiselement.enablecolorquery ?? false}
          onChange={(e) => 
            updateField(value, thiselement, onChange, "enablecolorquery", e.currentTarget.checked)
          }
          label='Use query for element color'
        />
      </Field>
      
      {thiselement.enablecolorquery && (
        <Field label="Data for element color" description="Select data for element color">
          <Combobox
            onChange={(e: ComboboxOption<string>) => {
              updateField(value, thiselement, onChange, "colorquery", e.value);
            }}
            value={thiselement.colorquery}
            options={datasources}
          />
        </Field>
      )}
      
      <Field label="Use gradient for element color" description="Use gradient for color">
        <Switch 
          defaultChecked={thiselement.usegradient ?? false}
          onChange={(e) => 
            updateField(value, thiselement, onChange, "usegradient", e.currentTarget.checked)
          }
          label='Use gradient for element color'
        />
      </Field>
      {thiselement.usegradient && <Field label="Use custom gradient for element color" description="Use custom gradient for color">
        <Switch 
          defaultChecked={thiselement.useowngradient ?? false}
          onChange={(e) => 
            updateField(value, thiselement, onChange, "useowngradient", e.currentTarget.checked)
          }
          label='Use gradient for element color'
        />
      </Field>}
        {thiselement.usegradient && <><Field label="Use data points for gradient">
            <Switch
              
              value={thiselement.gradientdata || false}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientdata", e.currentTarget.checked);
              }}
            />
          </Field>
          
          
 <Field label="Load coordinates from JSON file">
          <><div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              ref={fileInputRefCoordinates}
              style={{ display: 'none' }}
            />
            <Button aria-label="Upload coordinates" variant='primary' icon="upload" onClick={handleButtonCoordinatesClick} />
            
            {tempPoints.length > 0 && (
              <Button aria-label="Apply uploaded coordinates" variant="secondary" onClick={applyUploadedPoints}>
                Apply
              </Button>
            )}
          </div>
          
          {errorcoordinates && (
            <div style={{ color: 'red', marginTop: '8px' }}>
              {errorcoordinates}
            </div>
          )}
          
          {tempPoints.length > 0 && (
            <div style={{ marginTop: '8px' }}>
              Points loaded: {tempPoints.length}
            </div>
          )}
        </></Field></>}
           {thiselement.usegradient && thiselement.gradientdata && <><Field label={"Gradient step from 0 to 1"}
           >
            <Input value={thiselement.gradientcolor?.gradientstep}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.gradientstep", e.currentTarget.value);
              }}/>
            </Field>
            <Field label={"Gradient resolution width"}
           >
            <Input value={thiselement.gradientcolor?.width}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.width", e.currentTarget.value);
              }}/>
            </Field>
            <Field label={"Gradient resolution height"}
           >
            <Input value={thiselement.gradientcolor?.height}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.height", e.currentTarget.value);
              }}/>
            </Field>
          <Field label={"Gradient transparency from 0 to 1"}
           >
            <Input value={thiselement.gradientcolor?.opacity}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.opacity", e.currentTarget.value);
              }}/>
            </Field>


          <Field label={"Gradient type"}
           >
            <Combobox value={thiselement.gradientcolor?.gradienttype}
            options={gradientoptions}
            onChange={(e) => {
                updateField(value, thiselement, onChange, "gradientcolor.gradienttype", e.value);

              }}/>
            </Field> 
         {thiselement.gradientcolor?.gradienttype === "kriging" && <> <Field label={"Range for variogram"}
           >
            <Input value={thiselement.gradientcolor?.krigingRange}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.krigingRange", e.currentTarget.value);
              }}/>
            </Field>
          <Field label={"Nugget effect for variogram"}
           >
            <Input value={thiselement.gradientcolor?.krigingNugget}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.krigingNugget", e.currentTarget.value);
              }}/>
            </Field>
          <Field label={"Variogram plateau"}
           >
            <Input value={thiselement.gradientcolor?.krigingSill}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.krigingSill", e.currentTarget.value);
              }}/>
            </Field> </> }
{thiselement.gradientcolor?.gradienttype === "RBF" && <> <Field label={"Shape parameter for RBF"}
           >
            <Input value={thiselement.gradientcolor?.rbfEpsilon}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.rbfEpsilon", e.currentTarget.value);
              }}/>
            </Field>
          <Field label={"Smoothing parameter"}
           >
            <Input value={thiselement.gradientcolor?.rbfSmooth}               onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                updateField(value, thiselement, onChange, "gradientcolor.rbfSmooth", e.currentTarget.value);
              }}/>
            </Field>
                  <Field label={"Basis function type"}
           >
            <Combobox value={thiselement.gradientcolor?.rbfFunction}
            options={rbfoptions}
            onChange={(e) => {
                updateField(value, thiselement, onChange, "gradientcolor.rbfFunction", e.value);

              }}/>
            </Field> 
 </> }                                           
            </>}
          {thiselement.usegradient && thiselement.gradientdata &&
           <CollapsElement label="Point coordinates">
                  {(thiselement.gradientcolor?.points || []).map((point: CenterPosition, zz) => {
                    return (
                      <Field label={"Point " + (zz + 1)} key={zz}>
                        <>
                          <Field label="X coordinate">
                            <Input
                              id="pointx"
                              value={point.x || ""}
                              placeholder="0"
                              onChange={(e) => { 
                                const newPoints = [...(thiselement.gradientcolor?.points || [])];
                                newPoints[zz] = { ...newPoints[zz], x: e.currentTarget.value };
                                updateField(value, thiselement, onChange, "gradientcolor.points", newPoints);
                              }}
                            /> 
                          </Field>
                          
                          <Field label="Y coordinate">
                            <Input
                              id="pointy"
                              value={point.y || ""}
                              placeholder="0"
                              onChange={(e) => { 
                                const newPoints = [...(thiselement.gradientcolor?.points || [])];
                                newPoints[zz] = { ...newPoints[zz], y: e.currentTarget.value };
                                updateField(value, thiselement, onChange, "gradientcolor.points", newPoints);
                              }}
                            /> 
                          </Field>
                          <Field label="Data for point color" description="Select data for point color">
                            <Combobox
                              onChange={(e: ComboboxOption<string>) => {
                                 const newPoints = [...(thiselement.gradientcolor?.points || [])];
                                newPoints[zz] = { ...newPoints[zz], data: e.value };
                                updateField(value, thiselement, onChange, "gradientcolor.points", newPoints);
                              }}
                              value={point.data}
                              options={datasources}
                            />
                          </Field>
                          <div style={{ display: 'flex', gap: '4px', marginTop: '8px' }}>
                            <Button
                              aria-label="Move up"
                              title="Move up"
                              icon="arrow-up"
                              variant="secondary"
                              size="md"
                              disabled={zz === 0}
                              onClick={(e) => {
                                e.stopPropagation();
                                const newPoints = [...(thiselement.gradientcolor?.points || [])];
                                [newPoints[zz - 1], newPoints[zz]] = [newPoints[zz], newPoints[zz - 1]];
                                updateField(value, thiselement, onChange, "gradientcolor.points", newPoints);
                              }}
                            />
                            
                            <Button
                              aria-label="Move down"
                              title="Move down"
                              icon="arrow-down"
                              variant="secondary"
                              size="md"
                              disabled={zz === (thiselement.gradientcolor?.points?.length || 0) - 1}
                              onClick={(e) => {
                                e.stopPropagation();
                                const newPoints = [...(thiselement.gradientcolor?.points || [])];
                                [newPoints[zz], newPoints[zz + 1]] = [newPoints[zz + 1], newPoints[zz]];
                                updateField(value, thiselement, onChange, "gradientcolor.points", newPoints);
                              }}
                            />
                            
                            <Button
                              aria-label="Delete point"
                              title="Delete point"
                              icon="trash-alt"
                              variant="destructive"
                              size="md"
                              onClick={(e) => {
                                e.stopPropagation();
                                const newPoints = (thiselement.gradientcolor?.points  || []).filter((_, index) => index !== zz);
                                updateField(value, thiselement, onChange, "gradientcolor.points", newPoints);
                              }}
                            />
                          </div>
                        </>
                      </Field>
                    );
                  })}
                  
                  <Button
                    aria-label="Add point"
                    title="Add point"
                    icon="plus"
                    variant="primary"
                    size="md"
                    onClick={(e) => {
                      e.stopPropagation();
                      const newPoints = [...(thiselement.gradientcolor?.points || []), { x: "0", y: "0" }];
                      updateField(value, thiselement, onChange, "gradientcolor.points", newPoints);
                    }}
                  />
                </CollapsElement>
          }
{thiselement.usegradient && thiselement.useowngradient && (
  <CollapsElement label="Gradient settings">
    {/* Lower gradient boundary color */}
    <Field label="Lower gradient boundary color">
      <section>
        <HslColorPicker 
          color={{
            h: thiselement.gradientcolor?.lowvaluegradientcolor?.h || 45, 
            s: thiselement.gradientcolor?.lowvaluegradientcolor?.s || 100, 
            l: thiselement.gradientcolor?.lowvaluegradientcolor?.l || 50
          }} 
          onChange={(color: HslColor) => {
            const currentGradient = thiselement.gradientcolor || {};
            const currentHighColor = currentGradient.highvaluegradientcolor || { 
              h: 45, s: 100, l: 50 
            };

            updateField(
              value,
              thiselement,
              onChange,
              {
                gradientcolor: {
                  ...currentGradient,
                  lowvaluegradientcolor: color,
                  highvaluegradientcolor: {
                    ...currentHighColor,
                    s: color.s,
                    l: color.l
                  }
                }
              }
            );
          }} 
        />
      </section>
    </Field>
    
    {/* Upper gradient boundary color */}
    <Field label="Upper gradient boundary color">
      <section>
        <HslColorPicker 
          color={{
            h: thiselement.gradientcolor?.highvaluegradientcolor?.h || 45, 
            s: thiselement.gradientcolor?.highvaluegradientcolor?.s || 100, 
            l: thiselement.gradientcolor?.highvaluegradientcolor?.l || 50
          }} 
          onChange={(color: HslColor) => {
            const currentGradient = thiselement.gradientcolor || {};
            const currentLowColor = currentGradient.lowvaluegradientcolor || { 
              h: 45, s: 100, l: 50 
            };

            updateField(
              value,
              thiselement,
              onChange,
              {
                gradientcolor: {
                  ...currentGradient,
                  highvaluegradientcolor: color,
                  lowvaluegradientcolor: {
                    ...currentLowColor,
                    s: color.s,
                    l: color.l
                  }
                }
              }
            );
          }} 
        />
      </section>
    </Field>
    
    <Field label="Upper gradient boundary value">
      <Input
        placeholder="0"
        value={String(thiselement.gradientcolor?.highvalueforgradient || "")}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
          updateField(
            value,
            thiselement,
            onChange,
            "gradientcolor.highvalueforgradient", 
            e.currentTarget.value
          );
        }}
      />
    </Field>
    
    <Field label="Lower gradient boundary value">
      <Input
        placeholder="0"
        value={String(thiselement.gradientcolor?.lowvalueforgradient || "")}
        onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
          updateField(
            value,
            thiselement,
            onChange,
            "gradientcolor.lowvalueforgradient", 
            e.currentTarget.value
          );
        }}
      />
    </Field>
  </CollapsElement>
)}
      
      {!thiselement.enablecolorquery && (
        <Field label="Element color">
          <ColorPicker
            color={String(thiselement.color || "")}
            onChange={(color) => {
              updateField(value, thiselement, onChange, "color", color);
            }}
          />
        </Field>
      )}
      
      {thiselement.type === "grid" && (
        <Field label="Center lines color">
          <ColorPicker
            color={String(thiselement.center_grid_color || "")}
            onChange={(color) => {
              updateField(value, thiselement, onChange, "center_grid_color", color);
            }}
          />
        </Field>
      )} 
    </CollapsElement>
  );
}
