import React from "react";
import { GradientMaterial } from "Materials/GradientWithtexture";
import { DataTexture, FrontSide, Texture } from "three";

export default function ElementMaterial({
  el,
  elcolor,
  texture,
  loading,
  error,
  gradientTexture,
}: {
  el: any;
  elcolor: string;
  texture: Texture | null;
  loading: boolean;
  error: string | null;
  gradientTexture?: DataTexture | null;
}) {
  const opacity = Number(el.opacity ?? 1);
  const common = {
    opacity,
    transparent: opacity < 1,
    depthWrite: opacity >= 1,
    side: el.double_side ? 2 : FrontSide,
    attach: "material" as const,
  };

  if (
    el.usetextures &&
    el.usegradient &&
    texture &&
    gradientTexture &&
    !loading &&
    !error &&
    el.gradientdata &&
    el.gradientcolor?.points
  ) {
    return (
      <GradientMaterial
        opacity={opacity}
        baseTexture={texture}
        sideDouble={el.double_side}
        gradientTexture={gradientTexture}
        width={Number(el.gradientcolor.width)}
        gradientOpacity={Number(el.gradientcolor.opacity)}
        height={Number(el.gradientcolor.height)}
      />
    );
  }

  if (el.gradientdata && el.usegradient && gradientTexture && el.gradientcolor?.points) {
    return <meshStandardMaterial {...common} map={gradientTexture} />;
  }

  if (el.usetextures && texture && !loading && !error) {
    return <meshStandardMaterial {...common} map={texture} color={elcolor} />;
  }

  return <meshStandardMaterial {...common} color={elcolor} />;
}
