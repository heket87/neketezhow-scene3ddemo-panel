import React from "react";
import { Html, Text } from "@react-three/drei";
import * as THREE from "three";
import { Mesh, Vector3 } from "three";
import { FieldConfigSource, PanelData } from "@grafana/data";

import create_text from "../create_text";
import { ElementOptions, Options, TransformMode } from "../types";
import Mytransforms from "./Transform";
import Visibility from "./Data_driven_visibility";
import ElementMaterial from "./ElementMaterial";
import {
  renderClickHandler,
  renderGeometry,
  renderHoverHandlers,
  renderTextWindow,
  renderEdges,
} from "./elementRenderHelpers";
import { showHelpInfo, hideHelpInfo } from "../GlobalFunctions/helpWindowState";
import {
  createPositionDependencySignature,
  isElementPositionReferenceReady,
  resolveElementLocalPosition,
  resolveElementWorldPosition,
  usePositionReferenceRegistryVersion,
} from "GlobalFunctions/positionReferenceHelpers";

type ResolvedLinePoint = { x: number; y: number; z: number };

function to3DNumber(value: unknown): number {
  return Number(String(value ?? "").replace(",", "."));
}

function getLineElementKey(element: ElementOptions, index: number): string {
  const item = element as ElementOptions & {
    id?: string | number;
    uid?: string | number;
    elementid?: string | number;
    name?: string;
    label?: string;
  };

  return String(item.id ?? item.uid ?? item.elementid ?? item.name ?? item.label ?? `${element.type}-${index}`);
}

function buildCustomShape(points?: { x: string; y: string }[]) {
  if (!points?.length) {
    return null;
  }

  const shape = new THREE.Shape();
  points.forEach((point, index) => {
    const x = to3DNumber(point.x);
    const y = to3DNumber(point.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      return;
    }
    if (index === 0) {
      shape.moveTo(x, y);
    } else {
      shape.lineTo(x, y);
    }
  });
  shape.closePath();
  return new THREE.ShapeGeometry(shape);
}

export default function LoadBaseElement({
  el,
  data,
  elcolor,
  replaceVariables,
  fieldConfig,
  globaloptions,
  settriggerelement,
  allElements = [],
  onHoverStart,
  onHoverEnd,
}: {
  el: ElementOptions;
  data: PanelData;
  elcolor: string;
  replaceVariables: any;
  fieldConfig: FieldConfigSource<any>;
  globaloptions: Options;
  settriggerelement: React.Dispatch<React.SetStateAction<ElementOptions | undefined>>;
  allElements?: ElementOptions[];
  onHoverStart?: (e?: any) => void;
  onHoverEnd?: (e?: any) => void;
}) {
  const [mode, setMode] = React.useState<TransformMode>("translate");
  const [hovered, setHovered] = React.useState(false);
  const [texture, setTexture] = React.useState<THREE.Texture | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const groupref = React.useRef<THREE.Group | null>(null);
  const cuberef = React.useRef<Mesh | null>(null);

  const sceneElements = React.useMemo<ElementOptions[]>(() => {
    if (Array.isArray(allElements) && allElements.length > 0) {
      return allElements;
    }
    const maybeGlobalElements = (globaloptions as Options & { elements?: ElementOptions[] }).elements;
    return Array.isArray(maybeGlobalElements) ? maybeGlobalElements : [];
  }, [allElements, globaloptions]);

  const positionRegistryVersion = usePositionReferenceRegistryVersion();
  const sceneElementsSignature = React.useMemo(() => createPositionDependencySignature(sceneElements), [sceneElements]);

  const elementPosition = React.useMemo<[number, number, number]>(() => {
    void sceneElementsSignature;
    void positionRegistryVersion;
    return resolveElementLocalPosition(el, sceneElements);
  }, [el, sceneElements, sceneElementsSignature, positionRegistryVersion]);

  const positionReferenceReady = React.useMemo(() => {
    void positionRegistryVersion;
    return isElementPositionReferenceReady(el);
  }, [el, positionRegistryVersion]);

  const elementRotation = React.useMemo<[number, number, number]>(
    () => [
      THREE.MathUtils.degToRad(Number(el.rotationx) || 0),
      THREE.MathUtils.degToRad(Number(el.rotationy) || 0),
      THREE.MathUtils.degToRad(Number(el.rotationz) || 0),
    ],
    [el.rotationx, el.rotationy, el.rotationz]
  );

  const elementScale = React.useMemo<[number, number, number]>(
    () => [Number(el.elementsizeX) || 1, Number(el.elementsizeY) || 1, Number(el.elementsizeZ) || 1],
    [el.elementsizeX, el.elementsizeY, el.elementsizeZ]
  );

  React.useEffect(() => {
    if (!el.usetextures || !el.textures) {
      setTexture((prev) => {
        prev?.dispose();
        return null;
      });
      return;
    }

    setLoading(true);
    setError(null);

    let cancelled = false;
    const loader = new THREE.TextureLoader();
    loader.load(
      String(el.textures),
      (loadedTexture) => {
        if (cancelled) {
          loadedTexture.dispose();
          return;
        }

        loadedTexture.flipY = el.texture_flipY || false;
        if (el.texture_repeat) {
          loadedTexture.wrapS = THREE.RepeatWrapping;
          loadedTexture.wrapT = THREE.RepeatWrapping;
          loadedTexture.offset.set(Number(el.texture_offsetx) || 0, Number(el.texture_offsety) || 0);
          loadedTexture.repeat.set(Number(el.texture_repeatx) || 1, Number(el.texture_repeaty) || 1);
        }
        loadedTexture.needsUpdate = true;

        setTexture((prev) => {
          prev?.dispose();
          return loadedTexture;
        });
        setLoading(false);
      },
      undefined,
      (err) => {
        setError(String(err));
        setLoading(false);
      }
    );

    return () => {
      cancelled = true;
    };
  }, [
    el.usetextures,
    el.textures,
    el.texture_flipY,
    el.texture_repeat,
    el.texture_offsetx,
    el.texture_offsety,
    el.texture_repeatx,
    el.texture_repeaty,
  ]);

  React.useEffect(() => () => texture?.dispose(), [texture]);

  const customGeometry = React.useMemo(() => {
    if (el.type !== "Custom Element") {
      return null;
    }
    return buildCustomShape(el.points);
  }, [el.type, el.points]);

  React.useEffect(() => () => customGeometry?.dispose(), [customGeometry]);

  const rawLinePoints = React.useMemo<ResolvedLinePoint[]>(() => {
    void sceneElementsSignature;
    void positionRegistryVersion;

    if (el.type !== "Line3D") {
      return [];
    }

    const useManualPoints = el.line3d_set_points_manually ?? true;
    if (useManualPoints) {
      return (el.points3d || [])
        .map((p) => ({ x: to3DNumber(p.x), y: to3DNumber(p.y), z: to3DNumber(p.z) }))
        .filter((p) => Number.isFinite(p.x) && Number.isFinite(p.y) && Number.isFinite(p.z));
    }

    const lineOriginTuple = resolveElementWorldPosition(el, sceneElements);
    const linkedElements = Array.isArray(el.line3d_connected_elements) ? el.line3d_connected_elements : [];

    return linkedElements
      .map((linkedPoint) => {
        const linkedElement = sceneElements.find(
          (item, index) => getLineElementKey(item, index) === linkedPoint.elementId || String(item.id) === String(linkedPoint.elementId)
        );
        if (!linkedElement) {
          return null;
        }
        const linkedPositionTuple = resolveElementWorldPosition(linkedElement, sceneElements);
        return {
          x: linkedPositionTuple[0] - lineOriginTuple[0],
          y: linkedPositionTuple[1] - lineOriginTuple[1],
          z: linkedPositionTuple[2] - lineOriginTuple[2],
        };
      })
      .filter((p): p is ResolvedLinePoint => p !== null);
  }, [el, sceneElements, sceneElementsSignature, positionRegistryVersion]);

  const tubeGeometry = React.useMemo(() => {
    if (el.type !== "Line3D" || rawLinePoints.length < 2) {
      return null;
    }

    const pts = rawLinePoints.map((p) => new Vector3(p.x, p.y, p.z));
    const radius = Number(el.line3d_radius) > 0 ? Number(el.line3d_radius) : 0.1;
    const radialSegments = Math.max(3, Number(el.line3d_radial_segments) || 8);
    const closed = Boolean(el.line3d_closed);

    if (el.line3d_smooth) {
      return new THREE.TubeGeometry(
        new THREE.CatmullRomCurve3(pts, closed),
        Math.max(1, Number(el.line3d_tube_segments) || 64),
        radius,
        radialSegments,
        closed
      );
    }

    const path = new THREE.CurvePath<THREE.Vector3>();
    for (let i = 0; i < pts.length - 1; i++) {
      path.add(new THREE.LineCurve3(pts[i], pts[i + 1]));
    }
    if (closed && pts.length > 2) {
      path.add(new THREE.LineCurve3(pts[pts.length - 1], pts[0]));
    }
    return new THREE.TubeGeometry(path, Math.max(1, Number(el.line3d_tube_segments) || 64), radius, radialSegments, false);
  }, [el.type, el.line3d_radius, el.line3d_radial_segments, el.line3d_closed, el.line3d_smooth, el.line3d_tube_segments, rawLinePoints]);

  React.useEffect(() => () => tubeGeometry?.dispose(), [tubeGeometry]);

  const elementvisibility = Boolean(Visibility(false, data, "element", el, false, globaloptions.globaltext));
  const effectiveElementVisibility = elementvisibility && positionReferenceReady;

  const hoverHandlers = React.useMemo(() => {
    const base = renderHoverHandlers({ el, setHovered, showHelpInfo, hideHelpInfo });
    return {
      onPointerOver: (e: any) => {
        base.onPointerOver(e);
        onHoverStart?.(e);
      },
      onPointerOut: (e: any) => {
        base.onPointerOut(e);
        onHoverEnd?.(e);
      },
    };
  }, [el, onHoverStart, onHoverEnd]);

  const clickHandler = React.useMemo(() => renderClickHandler(el, replaceVariables), [el, replaceVariables]);

  const text = React.useMemo(
    () => create_text(el.textsettings?.text || el.name || "Text", replaceVariables, data, fieldConfig),
    [el.textsettings?.text, el.name, replaceVariables, data, fieldConfig]
  );

  const commonMeshProps = {
    ref: cuberef,
    onClick: clickHandler,
    onDoubleClick: () => settriggerelement(el),
    ...hoverHandlers,
  };

  const content = (() => {
    if (el.type === "text2d" || el.type === "text3d") {
      return (
        <Text
          {...hoverHandlers}
          onClick={clickHandler}
          onDoubleClick={() => settriggerelement(el)}
          fontSize={Number(el.fontsize) || 1}
          color={elcolor}
          anchorX="center"
          anchorY="middle"
          maxWidth={Number(el.text_of_element_width) || undefined}
        >
          {text}
        </Text>
      );
    }

    if (el.type === "Line3D" && tubeGeometry) {
      return (
        <mesh {...commonMeshProps} geometry={tubeGeometry}>
          <ElementMaterial el={el} elcolor={elcolor} texture={texture} loading={loading} error={error} />
          {renderEdges(el)}
        </mesh>
      );
    }

    return (
      <mesh {...commonMeshProps}>
        {el.type === "Custom Element" && customGeometry ? <primitive object={customGeometry} attach="geometry" /> : renderGeometry(el, Number(el.radiuis) || 1)}
        <ElementMaterial el={el} elcolor={elcolor} texture={texture} loading={loading} error={error} />
        {renderEdges(el)}
      </mesh>
    );
  })();

  if (!effectiveElementVisibility) {
    return null;
  }

  return (
    <Mytransforms
      visible={Boolean(el.enablecenter)}
      mode={mode}
      setMode={setMode}
      el={el}
      groupref={groupref}
      size={1}
    >
      <group ref={groupref} position={elementPosition} rotation={elementRotation} scale={elementScale}>
        {content}
        {renderTextWindow({
          el,
          replaceVariables,
          data,
          fieldConfig,
          hovered,
          globaloptions,
        })}
      </group>
    </Mytransforms>
  );
}
