import React from "react";
import { Edges } from "@react-three/drei";
import { useLoader } from "@react-three/fiber";
import * as THREE from "three";
import { MeshStandardMaterial } from "three";
import { PanelData } from "@grafana/data";

import { ElementOptions, Options } from "types";
import Mytransforms from "./Transform";

const FALLBACK_TEXTURE = "data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=";

export default function LoadGrid({
  el,
  elcolor,
  replaceVariables,
  globaloptions,
}: {
  el: ElementOptions;
  data: PanelData;
  elcolor: string;
  replaceVariables: any;
  globaloptions: Options;
  onHoverStart?: (e?: any) => void;
  onHoverEnd?: (e?: any) => void;
}) {
  const [mode, setMode] = React.useState<any>("translate");
  const groupref = React.useRef<THREE.Group | null>(null);

  const textureUrl = React.useMemo(() => (el.usetextures && el.textures ? String(el.textures) : FALLBACK_TEXTURE), [el.usetextures, el.textures]);
  const loadedTexture = useLoader(THREE.TextureLoader, textureUrl);

  const colorMap = React.useMemo(() => {
    if (!el.usetextures || !el.textures) {
      return undefined;
    }

    const texture = loadedTexture.clone();
    texture.flipY = el.texture_flipY ?? false;
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.offset.set(Number(el.texture_offsetx) || 0, Number(el.texture_offsety) || 0);
    texture.repeat.set(Number(el.texture_repeatx) || 1, Number(el.texture_repeaty) || 1);
    texture.needsUpdate = true;
    return texture;
  }, [loadedTexture, el.usetextures, el.textures, el.texture_flipY, el.texture_offsetx, el.texture_offsety, el.texture_repeatx, el.texture_repeaty]);

  React.useEffect(() => () => colorMap?.dispose(), [colorMap]);

  const material = React.useMemo(() => {
    const mat = new MeshStandardMaterial({ color: elcolor });
    if (colorMap) {
      mat.map = colorMap;
    }
    return mat;
  }, [elcolor, colorMap]);

  React.useEffect(() => () => material.dispose(), [material]);

  const position: [number, number, number] = [Number(el.elementaxisx) || 0, Number(el.elementaxisy) || 0, Number(el.elementaxisz) || 0];
  const rotation: [number, number, number] = [
    THREE.MathUtils.degToRad(Number(el.rotationx) || 0),
    THREE.MathUtils.degToRad(Number(el.rotationy) || 0),
    THREE.MathUtils.degToRad(Number(el.rotationz) || 0),
  ];

  void replaceVariables;
  void globaloptions;

  return (
    <Mytransforms visible={Boolean(el.enablecenter)} mode={mode} setMode={setMode} el={el} groupref={groupref} size={1}>
      <group ref={groupref} position={position} rotation={rotation}>
        <mesh material={material}>
          <boxGeometry args={[Number(el.elementsizeX) || 1, Number(el.elementsizeY) || 1, Number(el.elementsizeZ) || 0.02]} />
          {el.bordersforelement && (
            <Edges linewidth={Number(el.bordersforelementwidth)} threshold={15} color={el.bordersforelementcolor} />
          )}
        </mesh>
      </group>
    </Mytransforms>
  );
}
