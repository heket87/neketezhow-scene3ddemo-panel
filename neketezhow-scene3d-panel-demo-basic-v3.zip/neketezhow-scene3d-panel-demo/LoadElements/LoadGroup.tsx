import React from "react";
import { FieldConfigSource, DataFrame, Field } from "@grafana/data";
import { Box3, Group, Vector3 } from "three";
import { ErrorBoundary } from "react-error-boundary";

import { ElementOptions, Options, TransformMode } from "types";
import { getColorFromData } from "../GlobalFunctions/getColorFromData";
import LoadGrid from "./loadGrid";
import LoadBaseElement from "./loadBaseElement";
import Mytransforms from "./Transform";
import Visibility from "./Data_driven_visibility";
import TextWindow from "./textwindow";
import {
  createPositionDependencySignature,
  isElementPositionReferenceReady,
  resolveElementLocalPosition,
  usePositionReferenceRegistryVersion,
} from "GlobalFunctions/positionReferenceHelpers";
import LoadModel from "./loadModel";

function samePoint(a?: [number, number, number], b?: [number, number, number], eps = 0.0001) {
  if (!a || !b) {return false;}
  return Math.abs(a[0] - b[0]) < eps && Math.abs(a[1] - b[1]) < eps && Math.abs(a[2] - b[2]) < eps;
}

function getCenterInRootLocalSpace(root: Group, target: Group): [number, number, number] | undefined {
  root.updateMatrixWorld(true);
  target.updateMatrixWorld(true);
  const box = new Box3().setFromObject(target);
  if (box.isEmpty()) {return undefined;}
  const worldCenter = new Vector3();
  box.getCenter(worldCenter);
  const localCenter = root.worldToLocal(worldCenter.clone());
  return [localCenter.x, localCenter.y, localCenter.z];
}

function sanitizeColor(color: string | undefined): string {
  if (typeof color === "string" && /^#[0-9a-fA-F]{8}$/.test(color)) {
    return color.slice(0, 7);
  }
  return color || "#FF00FF";
}

function getFieldLabel(frame: DataFrame, field: Field): string {
  return field.config?.displayNameFromDS || field.state?.displayName || frame.name || frame.refId || field.name;
}

function normalizeColorDataKey(dataKey: string, data: any): string {
  if (!dataKey?.includes(":")) {return dataKey;}
  const refId = dataKey.split(":", 1)[0];
  const fieldName = dataKey.split(":").slice(1).join(":");
  const frame = data.series?.find((s: any) => s.refId === refId);
  if (!frame) {return fieldName || refId || dataKey;}
  const field = frame.fields?.find((f: any) => f.name === fieldName);
  if (!field) {return fieldName || frame.name || frame.refId || dataKey;}
  return getFieldLabel(frame, field);
}

const MODEL_TYPES = new Set(["load gltf/glb"]);
const BASE_TYPES = new Set(["cube", "plane", "sphere", "text3d", "text2d", "Line3D", "Custom Element"]);

export default function LoadGroup({
  el,
  data,
  replaceVariables,
  fieldConfig,
  globaloptions,
  settriggerelement,
  onHoverStart,
  onHoverEnd,
  allElements = [],
}: {
  el: ElementOptions;
  data: any;
  replaceVariables: any;
  fieldConfig: FieldConfigSource<any>;
  globaloptions: Options;
  settriggerelement: React.Dispatch<React.SetStateAction<ElementOptions | undefined>>;
  onHoverStart?: (e?: any) => void;
  onHoverEnd?: (e?: any) => void;
  allElements?: ElementOptions[];
}) {
  const groupref = React.useRef<Group | null>(null);
  const contentRef = React.useRef<Group | null>(null);
  const [mode, setMode] = React.useState<TransformMode>("translate");
  const [hovered, setHovered] = React.useState(false);
  const [realCenter, setRealCenter] = React.useState<[number, number, number] | undefined>(undefined);
  const hoverDepthRef = React.useRef(0);

  const sceneElements = React.useMemo<ElementOptions[]>(() => {
    if (Array.isArray(allElements) && allElements.length > 0) {return allElements;}
    const maybeGlobalElements = (globaloptions as Options & { elements?: ElementOptions[] }).elements;
    return Array.isArray(maybeGlobalElements) ? maybeGlobalElements : [];
  }, [allElements, globaloptions]);

  const positionRegistryVersion = usePositionReferenceRegistryVersion();
  const sceneElementsSignature = createPositionDependencySignature(sceneElements);

  const elementPosition = React.useMemo<[number, number, number]>(() => {
    void positionRegistryVersion;
    void sceneElementsSignature;
    return resolveElementLocalPosition(el, sceneElements);
  }, [el, sceneElements, sceneElementsSignature, positionRegistryVersion]);

  const elementRotation = React.useMemo<[number, number, number]>(
    () => [((Number(el.rotationx) || 0) * Math.PI) / 180, ((Number(el.rotationy) || 0) * Math.PI) / 180, ((Number(el.rotationz) || 0) * Math.PI) / 180],
    [el.rotationx, el.rotationy, el.rotationz]
  );

  const elementScale = React.useMemo<[number, number, number]>(
    () => [Number(el.elementsizeX) || 1, Number(el.elementsizeY) || 1, Number(el.elementsizeZ) || 1],
    [el.elementsizeX, el.elementsizeY, el.elementsizeZ]
  );

  const effectiveElementVisibility =
    Boolean(Visibility(false, data, "element", el, false, globaloptions.globaltext)) && isElementPositionReferenceReady(el);

  const useGlobalLeaderSettings = el.textsettings?.useGlobalTextSettings !== false;
  const leaderSettings = useGlobalLeaderSettings ? globaloptions.globaltext : el.textsettings;
  const useRealCenterForText = leaderSettings?.use_real_center_for_text ?? false;

  React.useLayoutEffect(() => {
    if (!useRealCenterForText || !groupref.current || !contentRef.current) {
      setRealCenter(undefined);
      return;
    }
    const next = getCenterInRootLocalSpace(groupref.current, contentRef.current);
    if (next) {
      setRealCenter((prev) => (samePoint(prev, next) ? prev : next));
    }
  }, [useRealCenterForText, el.group_subs]);

  const preparedChildren = React.useMemo(() => el.group_subs || [], [el.group_subs]);

  const getElementColor = React.useCallback(
    (child: ElementOptions) => {
      const baseColor = sanitizeColor(child.color);
      if (!child.enablecolorquery || !child.colorquery) {
        return baseColor;
      }
      const dataKey = normalizeColorDataKey(String(child.colorquery), data);
      return sanitizeColor(
        getColorFromData(dataKey, data, fieldConfig, baseColor, {
          usegradient: !!child.usegradient,
          use_own_gradient: !!child.useowngradient,
          own_gradient: child.gradientcolor,
          global_gradient: globaloptions.gradientcolor,
        })
      );
    },
    [data, fieldConfig, globaloptions.gradientcolor]
  );

  const renderChild = React.useCallback(
    (child: ElementOptions) => {
      const sharedProps = {
        data,
        replaceVariables,
        fieldConfig,
        globaloptions,
        settriggerelement,
        allElements: sceneElements,
        onHoverStart: () => {
          hoverDepthRef.current += 1;
          setHovered(true);
          onHoverStart?.();
        },
        onHoverEnd: () => {
          hoverDepthRef.current = Math.max(0, hoverDepthRef.current - 1);
          if (hoverDepthRef.current === 0) {
            setHovered(false);
            onHoverEnd?.();
          }
        },
      };

      if (child.type && MODEL_TYPES.has(child.type) && String(child.elementurl) !== "Enter link") {
        return (
          <ErrorBoundary key={child.id} FallbackComponent={() => null}>
            <LoadModel {...sharedProps} el={child} url={String(child.elementurl)} />
          </ErrorBoundary>
        );
      }

      if (child.type === "grid") {
        return (
          <ErrorBoundary key={child.id} FallbackComponent={() => null}>
            <LoadGrid {...sharedProps} el={child} elcolor={getElementColor(child)} />
          </ErrorBoundary>
        );
      }

      if (child.type === "group") {
        return (
          <ErrorBoundary key={child.id} FallbackComponent={() => null}>
            <LoadGroup {...sharedProps} el={child} />
          </ErrorBoundary>
        );
      }

      if (!child.type || BASE_TYPES.has(child.type)) {
        return (
          <ErrorBoundary key={child.id} FallbackComponent={() => null}>
            <LoadBaseElement {...sharedProps} el={child} elcolor={getElementColor(child)} />
          </ErrorBoundary>
        );
      }

      return null;
    },
    [data, fieldConfig, getElementColor, globaloptions, onHoverEnd, onHoverStart, replaceVariables, sceneElements, settriggerelement]
  );

  if (!effectiveElementVisibility) {return null;}

  return (
    <Mytransforms visible={Boolean(el.enablecenter)} mode={mode} setMode={setMode} el={el} groupref={groupref} size={1}>
      <group ref={groupref} position={elementPosition} rotation={elementRotation} scale={elementScale}>
        <group ref={contentRef}>{preparedChildren.map(renderChild)}</group>
        <TextWindow
          subelement={false}
          el={el}
          replaceVariables={replaceVariables}
          data={data}
          fieldConfig={fieldConfig}
          hovered={hovered}
          globaloptions={globaloptions}
          meshCenter={realCenter}
        />
      </group>
    </Mytransforms>
  );
}
