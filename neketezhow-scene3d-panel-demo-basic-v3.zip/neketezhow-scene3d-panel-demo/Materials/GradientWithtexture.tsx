import React from 'react';
import * as THREE from 'three';

interface GradientMaterialProps {
  baseTexture: THREE.Texture;
  gradientTexture: THREE.DataTexture;
  /** Gradient overlay opacity (0–1) */
  gradientOpacity?: number;
  sideDouble?: boolean;
  width?: number;
  height?: number;
  opacity?: number;
}

export const GradientMaterial: React.FC<GradientMaterialProps> = ({
  baseTexture,
  gradientTexture,
  opacity,
  gradientOpacity = 0.5,
  sideDouble = false,
  width = 512,
  height = 512,
}) => {
  const combineTextures = React.useCallback((
    base: THREE.Texture,
    gradient: THREE.DataTexture,
    w: number,
    h: number
  ): THREE.CanvasTexture => {
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d')!;

    const baseImage = base.image as CanvasImageSource;

    // 👉 Draw base texture considering repeat and offset
    const repeatX = base.repeat.x || 1;
    const repeatY = base.repeat.y || 1;
    const offsetX = base.offset.x || 0;
    const offsetY = base.offset.y || 0;

    const tileWidth = w / repeatX;
    const tileHeight = h / repeatY;

    const startX = -offsetX * w;
    const startY = -offsetY * h;

    for (let x = startX; x < w; x += tileWidth) {
      for (let y = startY; y < h; y += tileHeight) {
        ctx.drawImage(baseImage, x, y, tileWidth, tileHeight);
      }
    }

    // 👉 Gradient (single overlay)
    const raw = gradient.image.data as Uint8Array;
    const gradientImageData = new ImageData(
      new Uint8ClampedArray(raw.buffer),
      gradient.image.width,
      gradient.image.height
    );
    const gradientCanvas = document.createElement('canvas');
    gradientCanvas.width = gradient.image.width;
    gradientCanvas.height = gradient.image.height;
    const gctx = gradientCanvas.getContext('2d')!;
    gctx.putImageData(gradientImageData, 0, 0);

    ctx.globalAlpha = gradientOpacity;
    ctx.drawImage(gradientCanvas, 0, 0, w, h);
    ctx.globalAlpha = 1;

    const finalTexture = new THREE.CanvasTexture(canvas);
    finalTexture.needsUpdate = true;

    return finalTexture;
  }, [gradientOpacity]);

  const combined = React.useMemo(() => {
    if (baseTexture && gradientTexture) {
      return combineTextures(baseTexture, gradientTexture, width, height);
    }
    return baseTexture;
  }, [baseTexture, gradientTexture, width, height, combineTextures]);

  React.useEffect(() => {
    return () => {
      // Dispose only the CanvasTexture we created; never the caller-owned baseTexture
      if (combined && combined !== baseTexture) {
        combined.dispose();
      }
    };
  }, [combined, baseTexture]);

  return (
    <meshStandardMaterial
      map={combined}
      opacity={opacity}
      transparent={true}
      depthWrite={opacity === undefined || opacity >= 1}
      side={sideDouble ? THREE.DoubleSide : THREE.FrontSide}
    />
  );
};
